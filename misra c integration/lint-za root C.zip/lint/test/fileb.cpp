
class X
    {
    int a;
    };
