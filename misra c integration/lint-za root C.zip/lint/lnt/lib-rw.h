
/*  This header file is intended to be used with the -header option
    as in -header(lib-rw.h).  Such an option has been placed in
    the file lib-rw.lnt.
 */

#ifdef __cplusplus
namespace std {}
using namespace std;
#endif
